import httpx
import time
from typing import Optional

class SynathicMonitor:
    def __init__(self):
        self.api_key = None
        self.endpoint = "http://localhost:8000/api/events"
        self._client = None

    def start(self, api_key: Optional[str] = None, endpoint: Optional[str] = None):
        self.api_key = api_key
        if endpoint:
            self.endpoint = endpoint
        self._client = httpx.AsyncClient(timeout=5.0)
        print("Synathic monitor started")

    async def send_event(self, execution_id: str, agent_name: str, event_type: str, payload: dict):
        if not self._client:
            return

        try:
            await self._client.post(
                self.endpoint,
                json={
                    "execution_id": execution_id,
                    "agent_name": agent_name,
                    "event_type": event_type,
                    "payload": payload,
                    "timestamp": time.time()
                }
            )
        except Exception:
            # Fire-and-forget: si el backend está caído, el agente sigue corriendo
            pass

monitor = SynathicMonitor()