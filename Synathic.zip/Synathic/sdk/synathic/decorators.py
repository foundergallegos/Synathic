import functools
import asyncio
import uuid
from .monitor import monitor

def expect(postcondition: str, table: str = None, match_field: str = None):
    def decorator(func):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            execution_id = str(uuid.uuid4())

            await monitor.send_event(
                execution_id=execution_id,
                agent_name=func.__name__,
                event_type="tool_call",
                payload={"args": str(args), "kwargs": str(kwargs)}
            )

            result = await func(*args, **kwargs)

            await monitor.send_event(
                execution_id=execution_id,
                agent_name=func.__name__,
                event_type="tool_result",
                payload={
                    "result": str(result),
                    "postcondition": {
                        "type": postcondition,
                        "table": table,
                        "field": match_field,
                        "value": kwargs.get(match_field) or (args[0] if args else None)
                    }
                }
            )

            return result

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            return func(*args, **kwargs)

        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper

    return decorator