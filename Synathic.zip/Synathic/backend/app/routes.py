from fastapi import APIRouter, Depends, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from .database import get_db
from .models import Execution, Event, Verification
import uuid
from datetime import datetime
import asyncpg
import os

router = APIRouter()

@router.post("/events")
async def create_event(
    data: dict,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    execution_id = data.get("execution_id", str(uuid.uuid4()))

    event = Event(
        execution_id=execution_id,
        event_type=data.get("event_type"),
        payload=data.get("payload", {})
    )
    db.add(event)
    await db.commit()

    if data.get("event_type") == "tool_result":
        postcondition = data.get("payload", {}).get("postcondition")
        if postcondition:
            background_tasks.add_task(
                verify_postcondition,
                execution_id,
                postcondition
            )

    return {"status": "ok", "execution_id": execution_id}

@router.get("/executions")
async def list_executions(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Execution))
    executions = result.scalars().all()
    return executions

@router.get("/executions/{execution_id}")
async def get_execution(execution_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Execution).where(Execution.id == execution_id)
    )
    execution = result.scalar_one_or_none()

    events_result = await db.execute(
        select(Event).where(Event.execution_id == execution_id).order_by(Event.timestamp)
    )
    events = events_result.scalars().all()

    verif_result = await db.execute(
        select(Verification).where(Verification.execution_id == execution_id)
    )
    verifications = verif_result.scalars().all()

    return {
        "execution": execution,
        "events": events,
        "verifications": verifications
    }

async def verify_postcondition(execution_id: str, postcondition: dict):
    try:
        conn = await asyncpg.connect(os.getenv("DATABASE_URL", "").replace("+asyncpg", ""))

        if postcondition.get("type") == "row_exists":
            table = postcondition.get("table")
            field = postcondition.get("field")
            value = postcondition.get("value")

            query = f"SELECT 1 FROM {table} WHERE {field} = $1"
            row = await conn.fetchrow(query, value)

            status = "pass" if row else "fail"

            await conn.execute(
                "INSERT INTO verifications (execution_id, postcondition_type, target_table, match_field, match_value, status, checked_at) VALUES ($1, $2, $3, $4, $5, $6, $7)",
                execution_id, "row_exists", table, field, str(value), status, datetime.utcnow()
            )

        await conn.close()
    except Exception as e:
        print(f"Verification error: {e}")